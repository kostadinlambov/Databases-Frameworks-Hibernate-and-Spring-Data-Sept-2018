package alararestaurant.common;

public class Constants {

    public final static String SUCCESSFUL_ORDER_IMPORT_MESSAGE = "Order for %S on %s added";

    public final static String INVALID_DATA_FORMAT = "Invalid data format.";

    public final static String SUCCESSFUL_JSON_IMPORT_MESSAGE = "Record %s successfully imported.";
}
