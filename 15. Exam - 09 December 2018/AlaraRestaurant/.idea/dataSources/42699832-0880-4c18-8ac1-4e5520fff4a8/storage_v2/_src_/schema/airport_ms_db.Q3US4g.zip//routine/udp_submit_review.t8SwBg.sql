create procedure udp_submit_review(IN customer_id int, IN review_content varchar(255), IN review_grade int,
                                   IN airline_name varchar(30))
BEGIN
	DECLARE airline_id INT(11);

	SET airline_id := (SELECT a.airline_id FROM airlines AS a WHERE a.airline_name = airline_name);

    IF 1 != (SELECT COUNT(*) FROM airlines WHERE airlines.airline_id = airline_id) THEN
     SIGNAL SQLSTATE '45000'
	 SET MESSAGE_TEXT = 'Airline does not exist.';
    END IF;

    INSERT INTO customer_reviews(review_content, review_grade, airline_id, customer_id)
    VALUES(review_content, review_grade, airline_id, customer_id);
    
END;

