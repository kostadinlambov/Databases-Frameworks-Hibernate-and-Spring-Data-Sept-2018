create view v_top_payed_employee as
  select `e`.`id`            AS `id`,
         `e`.`first_name`    AS `first_name`,
         `e`.`last_name`     AS `last_name`,
         `e`.`job_title`     AS `job_title`,
         `e`.`department_id` AS `department_id`,
         `e`.`salary`        AS `salary`
  from `hospital`.`employees` `e`
  order by `e`.`salary` desc
  limit 1;

