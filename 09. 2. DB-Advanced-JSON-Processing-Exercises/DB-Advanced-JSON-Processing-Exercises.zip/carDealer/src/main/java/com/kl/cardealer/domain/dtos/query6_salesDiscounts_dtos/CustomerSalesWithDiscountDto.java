package com.kl.cardealer.domain.dtos.query6_salesDiscounts_dtos;

public class CustomerSalesWithDiscountDto {
}
