create view v_highest_peak as
  select `p`.`id`          AS `id`,
         `p`.`peak_name`   AS `peak_name`,
         `p`.`elevation`   AS `elevation`,
         `p`.`mountain_id` AS `mountain_id`
  from `geography`.`peaks` `p`
  order by `p`.`elevation` desc
  limit 1;

