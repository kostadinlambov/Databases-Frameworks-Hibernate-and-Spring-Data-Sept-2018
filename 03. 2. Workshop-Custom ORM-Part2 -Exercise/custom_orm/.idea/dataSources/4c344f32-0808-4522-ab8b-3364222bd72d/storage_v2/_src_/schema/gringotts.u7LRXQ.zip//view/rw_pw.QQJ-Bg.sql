create view rw_pw as
  select `w1`.`first_name`     AS `host_wizard`,
         `w1`.`deposit_amount` AS `host_wizard_deposit`,
         `w2`.`first_name`     AS `guest_wizard`,
         `w2`.`deposit_amount` AS `guest_wizard_deposit`
  from `gringotts`.`wizzard_deposits` `w1`
         join `gringotts`.`wizzard_deposits` `w2`
  where ((`w1`.`id` + 1) = `w2`.`id`);

