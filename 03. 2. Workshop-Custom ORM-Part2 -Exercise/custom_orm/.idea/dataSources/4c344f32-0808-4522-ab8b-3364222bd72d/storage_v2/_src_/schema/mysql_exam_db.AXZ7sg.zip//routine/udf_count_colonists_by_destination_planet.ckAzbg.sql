create function udf_count_colonists_by_destination_planet(planet_name varchar(30))
  returns int
  BEGIN
	DECLARE result INT(11);
	SET result := (SELECT count(c.id) FROM planets AS p
			LEFT JOIN spaceports AS sp
			ON p.id = sp.planet_id
			LEFT JOIN journeys AS j
			ON sp.id = j.destination_spaceport_id
			LEFT JOIN travel_cards AS tc
			ON j.id = tc.journey_id
			LEFT JOIN colonists AS c
			ON tc.colonist_id = c.id
            WHERE p.name = planet_name
			GROUP BY p.name);
    RETURN result;
END;

