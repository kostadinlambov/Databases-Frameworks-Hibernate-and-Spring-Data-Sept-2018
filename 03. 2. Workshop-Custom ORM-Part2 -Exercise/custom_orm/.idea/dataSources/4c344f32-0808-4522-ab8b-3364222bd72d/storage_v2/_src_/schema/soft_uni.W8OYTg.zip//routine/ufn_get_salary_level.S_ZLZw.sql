create function ufn_get_salary_level(empl_salary decimal(19, 4))
  returns varchar(10)
  BEGIN
	DECLARE result VARCHAR(10);
    IF empl_salary < 30000 THEN
    SET result := 'Low';
    ELSEIF empl_salary BETWEEN 30000 AND 50000 THEN
    SET result := 'Average';
    ELSEIF  empl_salary > 50000 THEN
    SET result := 'High';
    END IF;
	RETURN result;
END;

