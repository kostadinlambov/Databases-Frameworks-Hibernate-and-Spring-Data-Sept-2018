create procedure udp_purchase_ticket(IN customer_id int, IN flight_id int, IN ticket_price decimal(8, 2),
                                     IN class       varchar(6), IN seat varchar(5))
  BEGIN
	DECLARE balance DECIMAL(8, 2);
	SET balance := (SELECT cba.balance FROM customer_bank_accounts as cba WHERE cba.customer_id = customer_id);

	START TRANSACTION;

	IF (ticket_price > balance) THEN
		 SIGNAL SQLSTATE '45000'
		 SET MESSAGE_TEXT = 'Insufficient bank account balance for ticket purchase.';
		 ROLLBACK;
	ELSE 
		INSERT INTO tickets(price, class, seat, customer_id,flight_id )
		VALUES(ticket_price, class, seat, customer_id,flight_id );
		
		UPDATE customer_bank_accounts
		SET balance = balance - ticket_price
		WHERE customer_bank_accounts.customer_id = customer_id;
		COMMIT;
    END IF;
END;

