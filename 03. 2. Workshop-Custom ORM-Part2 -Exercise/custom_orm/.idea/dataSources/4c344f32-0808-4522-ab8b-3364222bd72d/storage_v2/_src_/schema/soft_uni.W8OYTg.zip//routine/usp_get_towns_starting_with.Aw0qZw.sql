create procedure usp_get_towns_starting_with(IN starts_with_string varchar(50))
  BEGIN
  SELECT t.name FROM towns AS t
  WHERE t.name LIKE CONCAT(starts_with_string, '%')
  ORDER BY t.name;
END;

