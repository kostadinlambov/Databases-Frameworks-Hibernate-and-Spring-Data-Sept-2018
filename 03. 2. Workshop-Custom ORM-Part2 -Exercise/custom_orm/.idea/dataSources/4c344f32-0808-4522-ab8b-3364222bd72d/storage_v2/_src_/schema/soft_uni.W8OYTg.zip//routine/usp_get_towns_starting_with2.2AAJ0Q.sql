create procedure usp_get_towns_starting_with2(IN str char(10))
  BEGIN
	SELECT t.name FROM towns AS t
	WHERE SUBSTRING(t.name, 1, char_length(str)) = str
    ORDER BY t.name;
END;

