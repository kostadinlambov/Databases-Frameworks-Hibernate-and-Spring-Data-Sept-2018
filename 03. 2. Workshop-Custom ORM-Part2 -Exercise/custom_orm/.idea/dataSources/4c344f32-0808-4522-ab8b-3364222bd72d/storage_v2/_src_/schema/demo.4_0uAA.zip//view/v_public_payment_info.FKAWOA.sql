create view v_public_payment_info as
  select `demo`.`customers`.`customer_id`                                   AS `id`,
         `demo`.`customers`.`first_name`                                    AS `first_name`,
         `demo`.`customers`.`last_name`                                     AS `last_name`,
         concat(left(`demo`.`customers`.`payment_number`, 6), '**********') AS `payment_number`
  from `demo`.`customers`;

