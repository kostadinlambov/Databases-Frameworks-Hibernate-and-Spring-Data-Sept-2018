create procedure usp_withdraw_money(IN account_id int, IN money_amount decimal(19, 4))
  BEGIN

	DECLARE new_balance DECIMAL(19, 4);
	IF money_amount > 0 THEN
		START TRANSACTION;
		
		UPDATE accounts
		SET balance = balance - money_amount
		WHERE id = account_id;
		

		SET new_balance := (SELECT a.balance FROM accounts AS a
							WHERE id = account_id);
		
		IF(new_balance < 0) THEN 
			ROLLBACK;
		ELSE
			COMMIT;
		END IF;
    END IF;
END;

