create view v_employees_hired_after_2000 as
  select `e`.`first_name` AS `first_name`, `e`.`last_name` AS `last_name`
  from `soft_uni`.`employees` `e`
  where (year(`e`.`hire_date`) > 2000);

