create procedure usp_transfer_money(IN from_account_id int, IN to_account_id int, IN amount decimal(19, 4))
  BEGIN
	DECLARE first_account_id_check BIT;
    DECLARE second_account_id_check BIT;
	DECLARE outgoing_balance_from DECIMAL(19, 4);
    DECLARE outgoing_balance_to DECIMAL(19, 4);
    IF amount > 0 THEN
		START TRANSACTION;
        
        UPDATE accounts
        SET balance = balance - amount
        WHERE id = from_account_id;
        
        UPDATE accounts
        SET balance = balance + amount
        WHERE id = to_account_id;
        
        SET outgoing_balance_from := (SELECT a.balance FROM accounts AS a WHERE id = from_account_id);
		SET outgoing_balance_to := (SELECT a.balance FROM accounts AS a WHERE id = to_account_id);
        SET first_account_id_check := ((SELECT count(*) FROM accounts AS a WHERE id = from_account_id) <> 1);
        SET second_account_id_check := ((SELECT count(*) FROM accounts AS a WHERE id = to_account_id) <> 1);
        
		IF( outgoing_balance_from < 0 OR outgoing_balance_to < 0 OR first_account_id_check OR second_account_id_check)
		THEN
			ROLLBACK;
        ELSE 
			COMMIT;
		END IF;
	END IF;
END;

