create trigger delete_user_trigger
  before DELETE
  on users
  for each row
  BEGIN
	DELETE FROM messages WHERE messages.user_id = OLD.id;
    DELETE FROM messages_log WHERE messages_log.user_id = OLD.id;
    DELETE FROM users_chats WHERE users_chats.user_id = OLD.id;
END;

