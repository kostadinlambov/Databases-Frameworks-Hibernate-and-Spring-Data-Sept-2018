create procedure udp_commit(IN username varchar(30), IN password varchar(30), IN message varchar(255), IN issue_id int)
  BEGIN
	DECLARE user_id INT(11);
    DECLARE repo_id INT(11);

	SET user_id := (SELECT u.id FROM users AS u WHERE u.username = username);
    SET repo_id := (SELECT i.repository_id FROM issues AS i WHERE  i.id = 2);
    
    IF 1 != (SELECT COUNT(*) FROM users WHERE users.id = user_id) THEN
     SIGNAL SQLSTATE '45000'
	 SET MESSAGE_TEXT = 'No such user!';
    END IF;
    
     IF 1 != (SELECT COUNT(*) FROM users WHERE users.id = user_id AND users.password = password) THEN
     SIGNAL SQLSTATE '45000'
	 SET MESSAGE_TEXT = 'Password is incorrect!';
    END IF;
    
	IF 1 != (SELECT COUNT(*) FROM issues WHERE issues.id = issue_id) THEN
	SIGNAL SQLSTATE '45000'
	SET MESSAGE_TEXT = 'The issue does not exist!';
    END IF;
    
    INSERT INTO commits(message, issue_id, repository_id, contributor_id)
    VALUES(message, issue_id, repo_id, user_id);
    
    UPDATE issues
    SET issue_status = 'closed'
    WHERE id = issue_id;

END;

