create function udf_get_radians(degrees float)
  returns float
  BEGIN
	DECLARE result FLOAT;
    SET result :=  (degrees * pi())/ 180; 
    RETURN result;
END;

