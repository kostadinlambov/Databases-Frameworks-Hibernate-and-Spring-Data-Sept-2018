create view max_currency_usage as
  select `currency_usage_contries`.`continent_code`            AS `max_continent_code`,
         `currency_usage_contries`.`currency_code`             AS `max_currency_usage_contries`,
         max(`currency_usage_contries`.`currency_usage_count`) AS `max_currency_usage_value`
  from (select `c`.`continent_code` AS `continent_code`,
               `c`.`currency_code`  AS `currency_code`,
               count(0)             AS `currency_usage_count`
        from `geography`.`countries` `c`
        group by `c`.`continent_code`, `c`.`currency_code`
        having (`currency_usage_count` > 1)) `currency_usage_contries`
  group by `currency_usage_contries`.`continent_code`;

