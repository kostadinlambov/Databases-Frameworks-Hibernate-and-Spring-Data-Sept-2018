create trigger delete_trigger
  after DELETE
  on messages
  for each row
  BEGIN
	INSERT INTO messages_log(id, content, sent_on, chat_id, user_id)
	VALUES(OLD.id, OLD.content, OLD.sent_on, OLD.chat_id, OLD.user_id);
END;

