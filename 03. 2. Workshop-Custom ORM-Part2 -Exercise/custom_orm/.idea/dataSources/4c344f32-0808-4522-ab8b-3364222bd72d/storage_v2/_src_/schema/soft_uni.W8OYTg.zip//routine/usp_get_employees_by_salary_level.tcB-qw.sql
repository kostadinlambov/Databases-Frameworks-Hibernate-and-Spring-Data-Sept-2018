create procedure usp_get_employees_by_salary_level(IN level_of_salary varchar(10))
  BEGIN
SELECT 
    e.first_name, e.last_name
FROM
    employees AS e
        JOIN
    (SELECT 
        e.employee_id, 
        e.salary,
        (CASE 
        WHEN e.salary < 30000 THEN 'low'
        WHEN e.salary BETWEEN 30000 AND 50000 THEN 'average'
        WHEN e.salary > 50000 THEN 'high'
        END) AS `salary_level`
		FROM employees AS e) AS `sl`
	ON e.employee_id = `sl`.employee_id
    WHERE level_of_salary = `sl`.`salary_level`
    ORDER BY e.first_name DESC, e.last_name DESC;
END;

