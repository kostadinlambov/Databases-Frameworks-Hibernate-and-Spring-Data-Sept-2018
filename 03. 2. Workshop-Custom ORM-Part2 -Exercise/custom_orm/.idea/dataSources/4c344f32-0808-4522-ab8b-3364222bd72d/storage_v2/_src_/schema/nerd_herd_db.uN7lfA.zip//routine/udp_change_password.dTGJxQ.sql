create procedure udp_change_password(IN email varchar(50), IN password varchar(50))
  BEGIN
    IF 1 != (SELECT COUNT(*) FROM credentials WHERE credentials.email = email) THEN
     SIGNAL SQLSTATE '45000'
	 SET MESSAGE_TEXT = "The email does't exist!";
    END IF;

    UPDATE credentials
    SET credentials.password = password
    WHERE credentials.email = email;
END;

