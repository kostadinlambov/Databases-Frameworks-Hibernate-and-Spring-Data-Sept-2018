create procedure udp_findbyextension(IN extension varchar(50))
  BEGIN
	SELECT f.id, f.name AS `caption`, concat(f.size, 'KB')  FROM files AS f
	WHERE f.name LIKE concat('%.', extension)
	ORDER BY f.id;
END;

