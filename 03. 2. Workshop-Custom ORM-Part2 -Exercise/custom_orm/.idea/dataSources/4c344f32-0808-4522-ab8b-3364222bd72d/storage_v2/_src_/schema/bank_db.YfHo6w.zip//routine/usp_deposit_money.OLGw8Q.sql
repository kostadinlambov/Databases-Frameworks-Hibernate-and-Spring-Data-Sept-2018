create procedure usp_deposit_money(IN account_id int, IN money_amount decimal)
  BEGIN
    START TRANSACTION;
    UPDATE accounts AS ac
    SET ac.balance = ac.balance + money_amount
    WHERE ac.id = account_id;
    IF (
    SELECT a.balance
    FROM accounts as a
    WHERE a.id = account_id
    ) >= 0 THEN
    COMMIT;
    ELSE
    rollback;
    END IF;
END;

