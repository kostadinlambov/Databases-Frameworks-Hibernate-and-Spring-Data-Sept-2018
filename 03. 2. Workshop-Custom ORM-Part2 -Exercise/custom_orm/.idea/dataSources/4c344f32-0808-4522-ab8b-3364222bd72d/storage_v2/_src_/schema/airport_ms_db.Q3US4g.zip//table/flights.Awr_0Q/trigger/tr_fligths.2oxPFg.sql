create trigger tr_fligths
  before UPDATE
  on flights
  for each row
  BEGIN
	DECLARE passengers INT(11);
	DECLARE origin VARCHAR(255);
	DECLARE destination VARCHAR(255);
    
	SET passengers = (SELECT COUNT(t.ticket_id) FROM tickets AS t
						JOIN flights AS f ON t.flight_id = f.flight_id
                        WHERE t.flight_id = NEW.flight_id);
                        
    SET origin = (SELECT ap.airport_name FROM flights AS f
					JOIN airports AS ap
				ON f.origin_airport_id = ap.airport_id
                WHERE ap.airport_id = NEW.origin_airport_id
                GROUP BY ap.airport_id);                    

	SET destination = (
					SELECT ap.airport_name FROM flights AS f
					JOIN airports AS ap
					ON f.destination_airport_id = ap.airport_id
					WHERE ap.airport_id = NEW.destination_airport_id
					GROUP BY ap.airport_id);

	IF(OLD.`status` = 'Deparing' OR OLD.`status` = 'Delayed') THEN

	INSERT INTO arrived_flights(flight_id, arrival_time, origin, destination, passengers)
	VALUES(NEW.flight_id, NEW.arrival_time, origin, destination, passengers);
   # UPDATE flights
	#SET arrival_time = now()
	#WHERE id = 1;
    END IF;
END;

