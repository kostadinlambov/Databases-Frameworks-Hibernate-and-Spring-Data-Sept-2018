create view v_employees_salaries as
  select `e`.`first_name` AS `first_name`, `e`.`last_name` AS `last_name`, `e`.`salary` AS `salary`
  from `soft_uni`.`employees` `e`;

