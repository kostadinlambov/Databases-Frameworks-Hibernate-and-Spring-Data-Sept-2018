create view v_employees_job_titles as
  select concat_ws(' ', `c`.`first_name`, `c`.`middle_name`, `c`.`last_name`) AS `full_name`,
         `c`.`job_title`                                                      AS `job_title`
  from `soft_uni`.`custom_table` `c`;

