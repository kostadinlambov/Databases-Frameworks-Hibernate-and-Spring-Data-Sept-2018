create procedure udp_send_message(IN user_id int, IN chat_id int, IN content varchar(255))
  BEGIN
    IF 1 > (SELECT count(*) FROM users AS u
				JOIN users_chats AS uc
				ON u.id = uc.user_id
                WHERE user_id = u.id
				GROUP BY u.id) 
		 THEN
		 SIGNAL SQLSTATE '45000'
		 SET MESSAGE_TEXT = 'There is no chat with that user!';
    END IF;

    INSERT INTO messages(content, sent_on, chat_id, user_id)
    VALUES(content, '2016-12-15', chat_id, user_id);
    
END;

