package p06_Birthday_Celebrations;

public interface Birthable {
  void printBirthdate(String year);
}
