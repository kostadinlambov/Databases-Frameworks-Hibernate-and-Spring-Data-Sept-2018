package p03_Ferrari;

public interface Car {
    String useBrakes();
    String useGasPedal();

}
