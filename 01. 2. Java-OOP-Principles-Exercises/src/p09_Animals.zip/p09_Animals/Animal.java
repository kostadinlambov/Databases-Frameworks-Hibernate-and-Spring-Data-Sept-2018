package p09_Animals;

public interface Animal extends SoundProducible {
}
