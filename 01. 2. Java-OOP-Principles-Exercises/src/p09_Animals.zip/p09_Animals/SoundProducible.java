package p09_Animals;

public interface SoundProducible {
    void produceSound();
}
