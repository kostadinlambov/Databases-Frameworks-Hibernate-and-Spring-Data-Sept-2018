package p04_Telephony;

import java.util.List;

public interface Browsable {
    void browse(String site);
}
