package p04_Telephony;

import java.util.List;

public interface Callable {
   void calling(String number);
}
