package kl.gamestore.domain.entities;

public enum Role {
    USER, ADMIN
}
